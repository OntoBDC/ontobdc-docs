
from typing import Any
from ontobdc.run.domain.port.ui import UserInterfaceFeedbackPort


class BrowserConsoleFeedbackAdapter(UserInterfaceFeedbackPort):
    """
    Adapter that implements communication with the user through 
    the browser's console/DOM via Pyodide.
    """
    def __init__(self):
        """
        Initializes the adapter and attempts to dynamically load the Pyodide 'js' module.
        It also patches the Python HTTP clients (like requests) to use the browser's fetch API.
        """
        self._js: object = None
        self._set_js_module()
        self._patch_http_clients()

    def _patch_http_clients(self) -> None:
        """
        Applies a monkey-patch to Python's native HTTP clients (urllib3/requests)
        so they route traffic through the browser's JavaScript fetch API.
        If not in a Pyodide environment, this silently skips.
        """
        try:
            import pyodide_http
            pyodide_http.patch_all()
        except ImportError as e:
            raise RuntimeError(
                "The 'pyodide_http' module is required for the BrowserConsoleFeedbackAdapter "
                "to handle HTTP requests inside the browser. Make sure to install it via micropip."
            ) from e

    def write(self, txt: str) -> None:
        """
        Sends a text fragment to the browser's console output.
        
        :param txt: The text fragment to output.
        """
        if txt.strip():
            self._js.updateOutput(txt.rstrip("\n"))
            
    def flush(self) -> None:
        """
        Ensures the message queue has been delivered to the interface.
        (No-op in this browser adapter implementation).
        """
        pass

    def __getattr__(self, name: str) -> Any:
        """
        Acts as a proxy to delegate attribute access to the underlying 'js' module.
        This enables calling native JavaScript functions seamlessly from Python.
        
        :param name: The name of the attribute or function to retrieve.
        :return: The attribute from the 'js' module.
        :raises AttributeError: If the attribute does not exist on the 'js' module.
        """
        js_module = self.get_js_module()
        if js_module and hasattr(js_module, name):
            return getattr(js_module, name)

        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")

    def get_base_url(self) -> str:
        """
        Retrieves the base URL of the host where the system is running
        using the browser's window object.
        
        :return: The base URL string.
        """
        return self.get_js_module().window.location.href.rsplit('/', 1)[0]

    def get_js_module(self) -> object:
        """
        Retrieves the underlying Pyodide 'js' module.
        
        :return: The loaded JavaScript module object.
        """
        return self._js

    def _set_js_module(self, js_module = None) -> None:
        """
        Sets the Pyodide 'js' module to be used by the adapter.
        If no module is provided, it lazily imports it.
        
        :param js_module: Optional explicit mock or js module object.
        """
        if js_module is None:
            if self.get_js_module() is None:
                import js
                self._js = js
        else:
            self._js = js_module
