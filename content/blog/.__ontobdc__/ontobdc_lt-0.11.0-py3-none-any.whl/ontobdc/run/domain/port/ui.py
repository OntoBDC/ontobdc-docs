
from abc import ABC, abstractmethod


class UserInterfaceFeedbackPort(ABC):
    """
    Abstract port responsible for forwarding execution feedback and system logs 
    directly to the user interface, regardless of the underlying platform 
    (Terminal, Web DOM, Desktop).
    """
    @abstractmethod
    def write(self, txt: str) -> None:
        """
        Sends a text fragment to the user.

        :param txt: The text fragment to be sent to the user interface.
        """
        pass
        
    @abstractmethod
    def flush(self) -> None:
        """
        Ensures the message queue has been delivered to the interface.
        """
        pass

    @abstractmethod
    def get_base_url(self) -> str:
        """
        Retrieves the base URL of the host where the system is running.
        
        :return: The base URL string.
        """
        pass

    @abstractmethod
    def get_js_module(self) -> object:
        """
        Retrieves the underlying Pyodide 'js' module.
        
        :return: The loaded JavaScript module object.
        """
        ...
